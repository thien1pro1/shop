package com.example.shop_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
