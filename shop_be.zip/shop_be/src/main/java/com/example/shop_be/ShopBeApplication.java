package com.example.shop_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopBeApplication.class, args);
	}

}
